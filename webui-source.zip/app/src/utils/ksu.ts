// KernelSU WebUI Interface
// Using official kernelsu npm package

import { exec, toast, fullScreen, moduleInfo } from 'kernelsu';

// Extend Window interface for KernelSU
declare global {
  interface Window {
    kesu?: {
      exec: (command: string) => Promise<{ errno: number; stdout: string; stderr: string }>;
    };
    ksu?: {
      exec: (command: string) => Promise<{ errno: number; stdout: string; stderr: string }>;
    };
  }
}

// Re-export official APIs
export { exec, toast, fullScreen, moduleInfo };

// Module paths
export const MODULE_PATH = '/data/adb/modules/github-cf-proxy';
export const BACKUP_DIR = `${MODULE_PATH}/backup`;
export const LOG_FILE = `${MODULE_PATH}/proxy.log`;
export const MODULES_DIR = '/data/adb/modules';
export const CONFIG_FILE = `${MODULE_PATH}/config.sh`;

// Check if running in KernelSU environment
export const isKSUEnvironment = (): boolean => {
  return typeof window.kesu !== 'undefined' || typeof window.ksu !== 'undefined';
};

// Execute shell command with better error handling
export const execCommand = async (command: string): Promise<{ 
  errno: number; 
  stdout: string; 
  stderr: string;
}> => {
  try {
    const result = await exec(command);
    return result;
  } catch (error) {
    console.error('Exec error:', error);
    return {
      errno: -1,
      stdout: '',
      stderr: String(error),
    };
  }
};

// Read file content using cat command
export const readFile = async (path: string): Promise<string> => {
  const { errno, stdout } = await execCommand(`cat "${path}" 2>/dev/null || echo ""`);
  return errno === 0 ? stdout : '';
};

// Write file content using echo command
export const writeFile = async (path: string, content: string): Promise<boolean> => {
  // Escape special characters for shell
  const escaped = content
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\$/g, '\\$')
    .replace(/`/g, '\\`');
  
  const { errno } = await execCommand(`echo "${escaped}" > "${path}"`);
  return errno === 0;
};

// Check if file exists
export const fileExists = async (path: string): Promise<boolean> => {
  const { errno } = await execCommand(`[ -f "${path}" ]`);
  return errno === 0;
};

// Check if directory exists
export const dirExists = async (path: string): Promise<boolean> => {
  const { errno } = await execCommand(`[ -d "${path}" ]`);
  return errno === 0;
};

// Create directory
export const mkdir = async (path: string): Promise<boolean> => {
  const { errno } = await execCommand(`mkdir -p "${path}"`);
  return errno === 0;
};

// List directory contents
export const listDir = async (path: string): Promise<string[]> => {
  const { errno, stdout } = await execCommand(`ls -1 "${path}" 2>/dev/null || echo ""`);
  if (errno !== 0) return [];
  return stdout.split('\n').filter(Boolean);
};

// Read module.prop file
export interface ModuleProp {
  id?: string;
  name?: string;
  version?: string;
  versionCode?: string;
  author?: string;
  description?: string;
  updateJson?: string;
  [key: string]: string | undefined;
}

export const readModuleProp = async (modulePath: string): Promise<ModuleProp> => {
  const content = await readFile(`${modulePath}/module.prop`);
  const prop: ModuleProp = {};
  
  content.split('\n').forEach(line => {
    const match = line.match(/^([^=]+)=(.*)$/);
    if (match) {
      prop[match[1].trim()] = match[2].trim();
    }
  });
  
  return prop;
};

// Write module.prop file
export const writeModuleProp = async (modulePath: string, prop: ModuleProp): Promise<boolean> => {
  const content = Object.entries(prop)
    .filter(([, value]) => value !== undefined)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');
  
  return writeFile(`${modulePath}/module.prop`, content);
};

// URL encode for worker
export const urlEncode = (url: string): string => {
  return encodeURIComponent(url)
    .replace(/!/g, '%21')
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29')
    .replace(/\*/g, '%2A')
    .replace(/~/g, '%7E');
};

// Check if URL is GitHub
export const isGitHubUrl = (url: string): boolean => {
  return url.toLowerCase().includes('github');
};

// Check if URL is already proxied
export const isProxiedUrl = (url: string, workerUrl: string): boolean => {
  return url.includes(workerUrl.replace(/^https?:\/\//, ''));
};

// Build worker URL
export const buildWorkerUrl = (originalUrl: string, workerUrl: string): string => {
  return `${workerUrl}/?url=${urlEncode(originalUrl)}`;
};

// Read log file
export const readLogs = async (): Promise<string[]> => {
  const content = await readFile(LOG_FILE);
  return content.split('\n').filter(Boolean);
};

// Append to log
export const appendLog = async (message: string): Promise<void> => {
  const timestamp = new Date().toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
  const escaped = message.replace(/"/g, '\\"');
  await execCommand(`echo "[${timestamp}] ${escaped}" >> "${LOG_FILE}"`);
};

// Run the proxy script
export const runProxyScript = async (): Promise<void> => {
  const { errno, stderr } = await execCommand(`sh ${MODULE_PATH}/service.sh`);
  if (errno !== 0) {
    throw new Error(stderr || 'Script execution failed');
  }
};

// Get module info from KernelSU
export const getModuleInfo = async () => {
  try {
    const info = await moduleInfo();
    return info;
  } catch (error) {
    console.error('Failed to get module info:', error);
    return null;
  }
};

// Show toast notification
export const showToast = (message: string): void => {
  toast(message);
};
