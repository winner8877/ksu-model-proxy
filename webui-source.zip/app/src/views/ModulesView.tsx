import { useState, useMemo } from 'react';
import { Package, Search, Filter, Shield, XCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ModuleCard } from '@/components/ModuleCard';
import type { ProxyModule } from '@/types';

interface ModulesViewProps {
  modules: ProxyModule[];
  onToggleProxy: (id: string) => void;
  onRestoreBackup: (id: string) => void;
}

type FilterType = 'all' | 'proxied' | 'unproxied';

export function ModulesView({ modules, onToggleProxy, onRestoreBackup }: ModulesViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');

  const filteredModules = useMemo(() => {
    return modules.filter(module => {
      // Search filter
      const matchesSearch = 
        module.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        module.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        module.author.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Status filter
      const matchesFilter = 
        filter === 'all' ? true :
        filter === 'proxied' ? module.isProxied :
        !module.isProxied;
      
      return matchesSearch && matchesFilter;
    });
  }, [modules, searchQuery, filter]);

  const stats = {
    total: modules.length,
    proxied: modules.filter(m => m.isProxied).length,
    unproxied: modules.filter(m => !m.isProxied).length,
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">模块管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            管理已安装的 Magisk/KernelSU 模块
          </p>
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-2">
          <span 
            className="md3-chip-filled"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-secondary-container))',
              color: 'hsl(var(--md-sys-color-on-secondary-container))'
            }}
          >
            <Package className="w-3.5 h-3.5" />
            共 {stats.total} 个
          </span>
          <span 
            className="md3-chip-filled"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
              color: 'hsl(var(--md-sys-color-on-primary-container))'
            }}
          >
            <Shield className="w-3.5 h-3.5" />
            {stats.proxied} 已代理
          </span>
          <span 
            className="md3-chip-filled"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-surface-variant))',
              color: 'hsl(var(--md-sys-color-on-surface-variant))'
            }}
          >
            <XCircle className="w-3.5 h-3.5" />
            {stats.unproxied} 未代理
          </span>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索模块名称、ID 或作者..."
            className="pl-10 md3-input"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <div className="flex gap-1">
            {(['all', 'proxied', 'unproxied'] as FilterType[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className="px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200"
                style={{
                  backgroundColor: filter === f 
                    ? 'hsl(var(--md-sys-color-primary-container))' 
                    : 'hsl(var(--md-sys-color-surface-container))',
                  color: filter === f 
                    ? 'hsl(var(--md-sys-color-on-primary-container))' 
                    : 'hsl(var(--md-sys-color-on-surface))'
                }}
              >
                {f === 'all' ? '全部' : f === 'proxied' ? '已代理' : '未代理'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          显示 {filteredModules.length} 个模块
          {searchQuery && ` (搜索: "${searchQuery}")`}
        </p>
      </div>

      {/* Modules Grid */}
      {filteredModules.length > 0 ? (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {filteredModules.map(module => (
            <ModuleCard
              key={module.id}
              module={module}
              onToggleProxy={onToggleProxy}
              onRestoreBackup={onRestoreBackup}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div 
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <Package className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground">未找到模块</h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-sm">
            {searchQuery 
              ? `没有找到匹配 "${searchQuery}" 的模块`
              : '当前筛选条件下没有模块'
            }
          </p>
          {searchQuery && (
            <Button 
              variant="outline" 
              onClick={() => setSearchQuery('')}
              className="mt-4"
            >
              清除搜索
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
