import { 
  Package, 
  Shield, 
  Clock, 
  Archive,
  RefreshCw,
  Play,
  Github,
  Server,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { StatCard } from '@/components/StatCard';
import { WorkerConfig } from '@/components/WorkerConfig';
import type { 
  ProxyModule, 
  ModuleStats, 
  WorkerConfig as WorkerConfigType,
  LogEntry 
} from '@/types';

interface DashboardViewProps {
  stats: ModuleStats;
  modules: ProxyModule[];
  logs: LogEntry[];
  config: WorkerConfigType;
  isLoading: boolean;
  isKSU: boolean;
  onRunScan: () => void;
  onUpdateWorkerUrl: (url: string) => void;
  onCheckWorker: () => void;
}

export function DashboardView({ 
  stats, 
  modules, 
  logs, 
  config,
  isLoading,
  isKSU,
  onRunScan,
  onUpdateWorkerUrl,
  onCheckWorker
}: DashboardViewProps) {
  const recentLogs = logs.slice(0, 5);
  const recentModules = modules.filter(m => m.isProxied).slice(0, 3);

  const formatDate = (date: Date | null) => {
    if (!date) return '从未';
    return new Intl.DateTimeFormat('zh-CN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">概览</h1>
          <p className="text-sm text-muted-foreground mt-1">
            GitHub CF Proxy 模块管理面板
          </p>
        </div>
        <div className="flex items-center gap-2">
          {!isKSU && (
            <span 
              className="px-3 py-1.5 rounded-full text-sm font-medium flex items-center gap-1.5"
              style={{
                backgroundColor: 'hsl(var(--md-sys-color-error-container))',
                color: 'hsl(var(--md-sys-color-on-error-container))'
              }}
            >
              <AlertTriangle className="w-4 h-4" />
              开发模式
            </span>
          )}
          <Button 
            onClick={onRunScan}
            disabled={isLoading}
            className="md3-btn-primary"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {isLoading ? '扫描中...' : '立即扫描'}
          </Button>
        </div>
      </div>

      {/* KSU Status Card */}
      {isKSU && (
        <div 
          className="p-4 rounded-2xl border flex items-center gap-3"
          style={{
            backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
            borderColor: 'hsl(var(--md-sys-color-primary-container))'
          }}
        >
          <CheckCircle2 
            className="w-5 h-5 flex-shrink-0" 
            style={{ color: 'hsl(var(--md-sys-color-on-primary-container))' }}
          />
          <div>
            <p 
              className="font-medium text-sm"
              style={{ color: 'hsl(var(--md-sys-color-on-primary-container))' }}
            >
              已连接到 KernelSU
            </p>
            <p 
              className="text-xs"
              style={{ color: 'hsl(var(--md-sys-color-on-primary-container))', opacity: 0.8 }}
            >
              模块路径: /data/adb/modules/github-cf-proxy
            </p>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="总模块数"
          value={stats.totalModules}
          subtitle={`${stats.proxiedModules} 个已代理`}
          icon={Package}
          color="primary"
        />
        <StatCard
          title="已代理"
          value={stats.proxiedModules}
          subtitle={`${stats.totalModules > 0 ? Math.round((stats.proxiedModules / stats.totalModules) * 100) : 0}% 覆盖率`}
          icon={Shield}
          color="success"
        />
        <StatCard
          title="待处理"
          value={stats.pendingModules}
          subtitle="可代理的模块"
          icon={Clock}
          color="warning"
        />
        <StatCard
          title="备份数"
          value={stats.backupCount}
          subtitle="原始配置备份"
          icon={Archive}
          color="info"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Worker Config */}
        <div className="lg:col-span-2">
          <WorkerConfig 
            config={config} 
            onUpdate={onUpdateWorkerUrl}
            onCheck={onCheckWorker}
          />
        </div>

        {/* Quick Actions */}
        <div className="md3-card p-5">
          <h3 className="font-semibold text-foreground mb-4">快速操作</h3>
          <div className="space-y-2">
            <button 
              onClick={onRunScan}
              disabled={isLoading}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-colors text-left disabled:opacity-50"
              style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
            >
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
                  color: 'hsl(var(--md-sys-color-on-primary-container))'
                }}
              >
                <Play className="w-5 h-5" />
              </div>
              <div>
                <p className="font-medium text-sm">启动服务</p>
                <p className="text-xs text-muted-foreground">运行代理脚本</p>
              </div>
            </button>
            
            <a 
              href="https://github.com/winner8877/ksu-model-proxy"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-colors text-left"
              style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
            >
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
                  color: 'hsl(var(--md-sys-color-on-primary-container))'
                }}
              >
                <Github className="w-5 h-5" />
              </div>
              <div>
                <p className="font-medium text-sm">查看源码</p>
                <p className="text-xs text-muted-foreground">在 GitHub 上查看</p>
              </div>
            </a>
            
            <button 
              onClick={onRunScan}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-colors text-left"
              style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
            >
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  backgroundColor: 'hsl(var(--md-sys-color-secondary-container))',
                  color: 'hsl(var(--md-sys-color-on-secondary-container))'
                }}
              >
                <Server className="w-5 h-5" />
              </div>
              <div>
                <p className="font-medium text-sm">全部代理</p>
                <p className="text-xs text-muted-foreground">为所有模块启用代理</p>
              </div>
            </button>
          </div>
          
          <div className="mt-5 pt-4 border-t border-border">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">上次扫描</span>
              <span className="font-medium">{formatDate(stats.lastScan)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Modules & Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Modules */}
        <div className="md3-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">已代理的模块</h3>
            <span className="text-xs text-muted-foreground">
              显示 {recentModules.length} 个
            </span>
          </div>
          
          {recentModules.length > 0 ? (
            <div className="space-y-3">
              {recentModules.map(module => (
                <div 
                  key={module.id}
                  className="flex items-center gap-3 p-3 rounded-2xl transition-colors"
                  style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
                >
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
                      color: 'hsl(var(--md-sys-color-on-primary-container))'
                    }}
                  >
                    <Shield className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-foreground truncate">
                      {module.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {module.id} · v{module.version}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">暂无已代理的模块</p>
            </div>
          )}
        </div>

        {/* Recent Logs */}
        <div className="md3-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">最近日志</h3>
            <span className="text-xs text-muted-foreground">
              显示 {recentLogs.length} 条
            </span>
          </div>
          
          {recentLogs.length > 0 ? (
            <div className="space-y-1 max-h-[280px] overflow-y-auto custom-scrollbar">
              {recentLogs.map((log, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-2 py-2 px-2 rounded-xl transition-colors"
                  style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
                >
                  <span 
                    className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                    style={{
                      backgroundColor: log.level === 'success' ? 'hsl(var(--success))' : 
                                       log.level === 'warning' ? 'hsl(var(--warning))' : 
                                       log.level === 'error' ? 'hsl(var(--destructive))' : 
                                       'hsl(var(--info))'
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-muted-foreground">
                      {log.timestamp.toLocaleTimeString('zh-CN')}
                    </p>
                    <p className="text-sm text-foreground truncate">
                      {log.message}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Server className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">暂无日志</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
