import { useState } from 'react';
import { 
  Settings, 
  Clock, 
  Bell, 
  Shield, 
  Trash2, 
  RefreshCw,
  Info,
  Github,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Sun,
  Moon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { WorkerConfig } from '@/components/WorkerConfig';
import type { WorkerConfig as WorkerConfigType } from '@/types';

interface SettingsViewProps {
  config: WorkerConfigType;
  isDarkMode: boolean;
  isKSU: boolean;
  onUpdateWorkerUrl: (url: string) => void;
  onToggleDarkMode: () => void;
  onCheckWorker: () => void;
}

export function SettingsView({ 
  config, 
  isDarkMode, 
  isKSU,
  onUpdateWorkerUrl,
  onCheckWorker
}: SettingsViewProps) {
  const [settings, setSettings] = useState({
    autoStart: true,
    autoScan: true,
    scanInterval: 24,
    notifications: true,
    backupBeforeProxy: true,
  });

  const handleSettingChange = (key: string, value: boolean | number) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">设置</h1>
        <p className="text-sm text-muted-foreground mt-1">
          配置代理模块的行为和偏好
        </p>
      </div>

      {/* KSU Status */}
      <div 
        className="p-4 rounded-2xl border flex items-center gap-3"
        style={{
          backgroundColor: isKSU 
            ? 'hsl(var(--md-sys-color-primary-container))' 
            : 'hsl(var(--md-sys-color-error-container))',
          borderColor: isKSU 
            ? 'hsl(var(--md-sys-color-primary))' 
            : 'hsl(var(--md-sys-color-error))'
        }}
      >
        {isKSU ? (
          <CheckCircle2 
            className="w-5 h-5 flex-shrink-0" 
            style={{ color: 'hsl(var(--md-sys-color-on-primary-container))' }}
          />
        ) : (
          <AlertTriangle 
            className="w-5 h-5 flex-shrink-0" 
            style={{ color: 'hsl(var(--md-sys-color-on-error-container))' }}
          />
        )}
        <div>
          <p 
            className="font-medium text-sm"
            style={{ 
              color: isKSU 
                ? 'hsl(var(--md-sys-color-on-primary-container))' 
                : 'hsl(var(--md-sys-color-on-error-container))' 
            }}
          >
            {isKSU ? 'KernelSU 环境正常' : '开发模式'}
          </p>
          <p className="text-xs text-muted-foreground">
            {isKSU 
              ? '模块路径: /data/adb/modules/github-cf-proxy'
              : '当前不在 KernelSU 环境中，使用模拟数据'
            }
          </p>
        </div>
      </div>

      {/* Worker Config */}
      <WorkerConfig 
        config={config} 
        onUpdate={onUpdateWorkerUrl}
        onCheck={onCheckWorker}
      />

      {/* Appearance - Auto Theme */}
      <div className="md3-card p-5">
        <div className="flex items-center gap-3 mb-5">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-tertiary-container))',
              color: 'hsl(var(--md-sys-color-on-tertiary-container))'
            }}
          >
            {isDarkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
          </div>
          <div>
            <h3 className="font-semibold text-foreground">外观</h3>
            <p className="text-xs text-muted-foreground">自动跟随系统设置</p>
          </div>
        </div>

        <div 
          className="flex items-center justify-between py-3 px-4 rounded-xl"
          style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
        >
          <div className="flex items-center gap-3">
            {isDarkMode ? (
              <Moon className="w-5 h-5 text-muted-foreground" />
            ) : (
              <Sun className="w-5 h-5 text-muted-foreground" />
            )}
            <div>
              <p className="font-medium text-sm text-foreground">
                {isDarkMode ? '深色模式' : '浅色模式'}
              </p>
              <p className="text-xs text-muted-foreground">
                根据系统自动切换
              </p>
            </div>
          </div>
          <span 
            className="text-xs px-2 py-1 rounded-full"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
              color: 'hsl(var(--md-sys-color-on-primary-container))'
            }}
          >
            自动
          </span>
        </div>
      </div>

      {/* General Settings */}
      <div className="md3-card p-5">
        <div className="flex items-center gap-3 mb-5">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-secondary-container))',
              color: 'hsl(var(--md-sys-color-on-secondary-container))'
            }}
          >
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">常规设置</h3>
            <p className="text-xs text-muted-foreground">基本行为配置</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Auto Start */}
          <div 
            className="flex items-center justify-between py-3 px-4 rounded-xl"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <div className="flex items-start gap-3">
              <RefreshCw className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="font-medium text-sm text-foreground">开机自启</p>
                <p className="text-xs text-muted-foreground">
                  系统启动后自动运行代理脚本
                </p>
              </div>
            </div>
            <Switch
              checked={settings.autoStart}
              onCheckedChange={(v) => handleSettingChange('autoStart', v)}
            />
          </div>

          {/* Auto Scan */}
          <div 
            className="flex items-center justify-between py-3 px-4 rounded-xl"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="font-medium text-sm text-foreground">自动扫描</p>
                <p className="text-xs text-muted-foreground">
                  定期检查新安装的模块
                </p>
              </div>
            </div>
            <Switch
              checked={settings.autoScan}
              onCheckedChange={(v) => handleSettingChange('autoScan', v)}
            />
          </div>

          {/* Notifications */}
          <div 
            className="flex items-center justify-between py-3 px-4 rounded-xl"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <div className="flex items-start gap-3">
              <Bell className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="font-medium text-sm text-foreground">通知提醒</p>
                <p className="text-xs text-muted-foreground">
                  代理状态变更时显示通知
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifications}
              onCheckedChange={(v) => handleSettingChange('notifications', v)}
            />
          </div>

          {/* Backup Before Proxy */}
          <div 
            className="flex items-center justify-between py-3 px-4 rounded-xl"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="font-medium text-sm text-foreground">代理前备份</p>
                <p className="text-xs text-muted-foreground">
                  启用代理前自动备份原始配置
                </p>
              </div>
            </div>
            <Switch
              checked={settings.backupBeforeProxy}
              onCheckedChange={(v) => handleSettingChange('backupBeforeProxy', v)}
            />
          </div>
        </div>
      </div>

      {/* Data Management */}
      <div className="md3-card p-5">
        <div className="flex items-center gap-3 mb-5">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-error-container))',
              color: 'hsl(var(--md-sys-color-on-error-container))'
            }}
          >
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">数据管理</h3>
            <p className="text-xs text-muted-foreground">清理和重置</p>
          </div>
        </div>

        <div className="space-y-3">
          <Button variant="outline" className="w-full justify-start">
            <Trash2 className="w-4 h-4 mr-2" />
            清除所有日志
          </Button>
          <Button variant="outline" className="w-full justify-start">
            <RefreshCw className="w-4 h-4 mr-2" />
            重置所有设置
          </Button>
          <Button variant="destructive" className="w-full justify-start">
            <Trash2 className="w-4 h-4 mr-2" />
            删除所有备份
          </Button>
        </div>
      </div>

      {/* About */}
      <div className="md3-card p-5">
        <div className="flex items-center gap-3 mb-5">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
              color: 'hsl(var(--md-sys-color-on-primary-container))'
            }}
          >
            <Info className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">关于</h3>
            <p className="text-xs text-muted-foreground">版本和链接</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-muted-foreground">版本</span>
            <span className="text-sm font-medium">v1.0.0</span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-muted-foreground">模块路径</span>
            <span className="text-sm font-medium font-mono">/data/adb/modules/github-cf-proxy</span>
          </div>
          
          <div className="flex gap-2 pt-2">
            <Button variant="outline" className="flex-1" asChild>
              <a 
                href="https://github.com/winner8877/ksu-model-proxy" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Github className="w-4 h-4 mr-2" />
                GitHub
              </a>
            </Button>
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => alert('这么简单的界面都不会用别玩了')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              文档
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
