import { useState, useMemo } from 'react';
import { FileText, Trash2, Download, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { LogEntryItem } from '@/components/LogEntry';
import type { LogEntry } from '@/types';

interface LogsViewProps {
  logs: LogEntry[];
  onClear: () => void;
}

type LogLevel = 'all' | 'info' | 'warning' | 'error' | 'success';

export function LogsView({ logs, onClear }: LogsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<LogLevel>('all');

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const matchesSearch = 
        log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (log.moduleId && log.moduleId.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesLevel = 
        levelFilter === 'all' ? true :
        log.level === levelFilter;
      
      return matchesSearch && matchesLevel;
    });
  }, [logs, searchQuery, levelFilter]);

  const levelCounts = useMemo(() => ({
    all: logs.length,
    info: logs.filter(l => l.level === 'info').length,
    warning: logs.filter(l => l.level === 'warning').length,
    error: logs.filter(l => l.level === 'error').length,
    success: logs.filter(l => l.level === 'success').length,
  }), [logs]);

  const handleExport = () => {
    const logText = logs.map(log => {
      const time = log.timestamp.toLocaleString('zh-CN');
      const level = log.level.toUpperCase();
      const module = log.moduleId ? `[${log.moduleId}] ` : '';
      return `[${time}] [${level}] ${module}${log.message}`;
    }).join('\n');
    
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `proxy-logs-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">运行日志</h1>
          <p className="text-sm text-muted-foreground mt-1">
            查看代理模块的运行状态和操作记录
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="w-4 h-4 mr-1.5" />
            导出
          </Button>
          <Button variant="destructive" size="sm" onClick={onClear}>
            <Trash2 className="w-4 h-4 mr-1.5" />
            清空
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap gap-2">
        {(['all', 'info', 'warning', 'error', 'success'] as LogLevel[]).map((level) => (
          <button
            key={level}
            onClick={() => setLevelFilter(level)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all duration-200"
            style={{
              backgroundColor: levelFilter === level 
                ? level === 'all' ? 'hsl(var(--md-sys-color-primary-container))' :
                  level === 'info' ? 'hsl(var(--md-sys-color-primary-container))' :
                  level === 'warning' ? 'hsl(var(--md-sys-color-tertiary-container))' :
                  level === 'error' ? 'hsl(var(--md-sys-color-error-container))' :
                  'hsl(var(--md-sys-color-primary-container))'
                : 'hsl(var(--md-sys-color-surface-container))',
              color: levelFilter === level 
                ? level === 'all' ? 'hsl(var(--md-sys-color-on-primary-container))' :
                  level === 'info' ? 'hsl(var(--md-sys-color-on-primary-container))' :
                  level === 'warning' ? 'hsl(var(--md-sys-color-on-tertiary-container))' :
                  level === 'error' ? 'hsl(var(--md-sys-color-on-error-container))' :
                  'hsl(var(--md-sys-color-on-primary-container))'
                : 'hsl(var(--md-sys-color-on-surface))'
            }}
          >
            {level === 'all' && '全部'}
            {level === 'info' && '信息'}
            {level === 'warning' && '警告'}
            {level === 'error' && '错误'}
            {level === 'success' && '成功'}
            <span 
              className="text-xs px-1.5 py-0.5 rounded-full"
              style={{
                backgroundColor: levelFilter === level ? 'rgba(255,255,255,0.2)' : 'hsl(var(--md-sys-color-surface-variant))'
              }}
            >
              {levelCounts[level]}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="搜索日志内容或模块 ID..."
          className="pl-10 md3-input"
        />
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          显示 {filteredLogs.length} 条日志
          {searchQuery && ` (搜索: "${searchQuery}")`}
        </p>
      </div>

      {/* Logs List */}
      {filteredLogs.length > 0 ? (
        <div className="md3-card overflow-hidden">
          <div className="divide-y divide-border">
            {filteredLogs.map((log, index) => (
              <LogEntryItem key={index} entry={log} />
            ))}
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div 
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <FileText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground">
            {searchQuery ? '未找到日志' : '暂无日志'}
          </h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-sm">
            {searchQuery 
              ? `没有找到匹配 "${searchQuery}" 的日志`
              : '日志将在这里显示'
            }
          </p>
          {searchQuery && (
            <Button 
              variant="outline" 
              onClick={() => setSearchQuery('')}
              className="mt-4"
            >
              清除搜索
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
