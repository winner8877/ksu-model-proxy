import { useState, useMemo } from 'react';
import { Archive, Search, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { BackupCard } from '@/components/BackupCard';
import type { ModuleBackup, ProxyModule } from '@/types';

interface BackupsViewProps {
  backups: ModuleBackup[];
  modules: ProxyModule[];
  onRestore: (id: string) => void;
  onDelete: (id: string) => void;
}

export function BackupsView({ backups, modules, onRestore, onDelete }: BackupsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredBackups = useMemo(() => {
    return backups.filter(backup => 
      backup.moduleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      backup.moduleId.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [backups, searchQuery]);

  // Modules without backups
  const unbackedModules = useMemo(() => {
    return modules.filter(m => !m.hasBackup && m.originalUrl.includes('github'));
  }, [modules]);

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">备份管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            管理模块配置的原始备份
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <span 
            className="md3-chip-filled"
            style={{
              backgroundColor: 'hsl(var(--md-sys-color-secondary-container))',
              color: 'hsl(var(--md-sys-color-on-secondary-container))'
            }}
          >
            <Archive className="w-3.5 h-3.5" />
            {backups.length} 个备份
          </span>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="搜索备份..."
          className="pl-10 md3-input"
        />
      </div>

      {/* Info Banner */}
      <div 
        className="p-4 rounded-2xl border flex items-start gap-3"
        style={{
          backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
          borderColor: 'hsl(var(--md-sys-color-primary-container))'
        }}
      >
        <CheckCircle2 
          className="w-5 h-5 flex-shrink-0 mt-0.5" 
          style={{ color: 'hsl(var(--md-sys-color-on-primary-container))' }}
        />
        <div>
          <h4 
            className="text-sm font-medium"
            style={{ color: 'hsl(var(--md-sys-color-on-primary-container))' }}
          >
            关于备份
          </h4>
          <p 
            className="text-xs mt-1 leading-relaxed"
            style={{ color: 'hsl(var(--md-sys-color-on-primary-container))', opacity: 0.8 }}
          >
            备份文件保存在模块目录的 backup 文件夹中。恢复备份会将模块的 updateJson 
            还原为原始的 GitHub URL，取消代理状态。
          </p>
        </div>
      </div>

      {/* Backups Grid */}
      {filteredBackups.length > 0 ? (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {filteredBackups.map(backup => (
            <BackupCard
              key={backup.moduleId}
              backup={backup}
              onRestore={onRestore}
              onDelete={onDelete}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div 
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <Archive className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground">
            {searchQuery ? '未找到备份' : '暂无备份'}
          </h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-sm">
            {searchQuery 
              ? `没有找到匹配 "${searchQuery}" 的备份`
              : '启用代理后会自动创建备份'
            }
          </p>
        </div>
      )}

      {/* Unbacked Modules Warning */}
      {unbackedModules.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle 
              className="w-5 h-5" 
              style={{ color: 'hsl(var(--warning))' }}
            />
            <h3 className="font-semibold text-foreground">
              未备份的模块 ({unbackedModules.length})
            </h3>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {unbackedModules.map(module => (
              <div 
                key={module.id}
                className="flex items-center gap-3 p-3 rounded-2xl border"
                style={{
                  backgroundColor: 'hsl(var(--md-sys-color-tertiary-container))',
                  borderColor: 'hsl(var(--md-sys-color-tertiary-container))'
                }}
              >
                <Archive 
                  className="w-5 h-5 flex-shrink-0" 
                  style={{ color: 'hsl(var(--md-sys-color-on-tertiary-container))' }}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-foreground truncate">
                    {module.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {module.id}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
