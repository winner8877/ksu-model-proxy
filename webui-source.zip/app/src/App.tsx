import { useEffect, useState } from 'react';
import { Navigation } from '@/components/Navigation';
import { DashboardView } from '@/views/DashboardView';
import { ModulesView } from '@/views/ModulesView';
import { BackupsView } from '@/views/BackupsView';
import { LogsView } from '@/views/LogsView';
import { SettingsView } from '@/views/SettingsView';
import { useKSU } from '@/hooks/useKSU';
import { toast as ksuToast } from 'kernelsu';
import type { ViewType } from '@/types';
import './App.css';

function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  
  // 深色模式：自动跟随系统
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // 检测系统深色模式偏好
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });
  
  const {
    isReady,
    isLoading,
    modules,
    backups,
    logs,
    config,
    stats,
    isKSU,
    updateWorkerUrl,
    toggleProxy,
    restoreBackup,
    deleteBackup,
    runScan,
    clearLogs,
    checkWorker,
  } = useKSU();

  // 监听系统深色模式变化
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      setIsDarkMode(e.matches);
    };
    
    // 添加监听器
    mediaQuery.addEventListener('change', handleChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleChange);
    };
  }, []);

  // 应用深色模式
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Show KSU environment notification
  useEffect(() => {
    if (isReady) {
      if (!isKSU) {
        ksuToast('开发模式：当前不在 KernelSU 环境中');
      } else {
        ksuToast('已连接到 KernelSU');
      }
    }
  }, [isReady, isKSU]);

  const handleUpdateWorkerUrl = async (url: string) => {
    try {
      await updateWorkerUrl(url);
    } catch (error) {
      ksuToast('更新失败: ' + (error as Error).message);
    }
  };

  const handleToggleProxy = async (id: string) => {
    try {
      await toggleProxy(id);
    } catch (error) {
      ksuToast('操作失败: ' + (error as Error).message);
    }
  };

  const handleRestoreBackup = async (id: string) => {
    try {
      await restoreBackup(id);
    } catch (error) {
      ksuToast('恢复失败: ' + (error as Error).message);
    }
  };

  const handleDeleteBackup = async (id: string) => {
    try {
      await deleteBackup(id);
    } catch (error) {
      ksuToast('删除失败: ' + (error as Error).message);
    }
  };

  const handleRunScan = async () => {
    try {
      await runScan();
    } catch (error) {
      ksuToast('扫描失败: ' + (error as Error).message);
    }
  };

  const handleClearLogs = async () => {
    try {
      await clearLogs();
    } catch (error) {
      ksuToast('清空失败: ' + (error as Error).message);
    }
  };

  const handleCheckWorker = async () => {
    await checkWorker();
  };

  const renderView = () => {
    if (!isReady) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-muted-foreground">正在初始化...</p>
          </div>
        </div>
      );
    }

    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            stats={stats}
            modules={modules}
            logs={logs}
            config={config}
            isLoading={isLoading}
            isKSU={isKSU}
            onRunScan={handleRunScan}
            onUpdateWorkerUrl={handleUpdateWorkerUrl}
            onCheckWorker={handleCheckWorker}
          />
        );
      case 'modules':
        return (
          <ModulesView
            modules={modules}
            onToggleProxy={handleToggleProxy}
            onRestoreBackup={handleRestoreBackup}
          />
        );
      case 'backups':
        return (
          <BackupsView
            backups={backups}
            modules={modules}
            onRestore={handleRestoreBackup}
            onDelete={handleDeleteBackup}
          />
        );
      case 'logs':
        return (
          <LogsView
            logs={logs}
            onClear={handleClearLogs}
          />
        );
      case 'settings':
        return (
          <SettingsView
            config={config}
            isDarkMode={isDarkMode}
            isKSU={isKSU}
            onUpdateWorkerUrl={handleUpdateWorkerUrl}
            onToggleDarkMode={() => {}}
            onCheckWorker={handleCheckWorker}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      {/* Navigation */}
      <Navigation
        currentView={currentView}
        onViewChange={setCurrentView}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => {}}
      />

      {/* Main Content */}
      <main className="ml-20 lg:ml-64 min-h-screen">
        {renderView()}
      </main>
    </div>
  );
}

export default App;
