import { useState } from 'react';
import { Globe, Check, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { WorkerConfig as WorkerConfigType } from '@/types';

interface WorkerConfigProps {
  config: WorkerConfigType;
  onUpdate: (url: string) => void;
  onCheck: () => void;
}

export function WorkerConfig({ config, onUpdate, onCheck }: WorkerConfigProps) {
  const [url, setUrl] = useState(config.url);
  const [isEditing, setIsEditing] = useState(false);
  const [isChecking, setIsChecking] = useState(false);

  const handleSave = () => {
    if (url.trim()) {
      onUpdate(url.trim());
      setIsEditing(false);
    }
  };

  const handleCheck = async () => {
    setIsChecking(true);
    await onCheck();
    setIsChecking(false);
  };

  return (
    <div className="md3-card p-5">
      <div className="flex items-center gap-3 mb-4">
        <div 
          className="w-10 h-10 rounded-2xl flex items-center justify-center"
          style={{
            backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
            color: 'hsl(var(--md-sys-color-on-primary-container))'
          }}
        >
          <Globe className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-semibold text-foreground">Worker 配置</h3>
          <p className="text-xs text-muted-foreground">Cloudflare Worker 代理地址</p>
        </div>
      </div>

      <div className="space-y-4">
        {isEditing ? (
          <div className="space-y-3">
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://your-worker.your-subdomain.workers.dev"
              className="md3-input"
            />
            <div className="flex gap-2">
              <Button onClick={handleSave} className="flex-1">
                <Check className="w-4 h-4 mr-1.5" />
                保存
              </Button>
              <Button variant="outline" onClick={() => {
                setUrl(config.url);
                setIsEditing(false);
              }}>
                取消
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div 
              className="p-3 rounded-xl font-mono text-sm text-foreground break-all"
              style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
            >
              {config.url}
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {config.isValid ? (
                  <span 
                    className="inline-flex items-center gap-1.5 text-xs"
                    style={{ color: 'hsl(var(--success))' }}
                  >
                    <Check className="w-3.5 h-3.5" />
                    连接正常
                  </span>
                ) : (
                  <span 
                    className="inline-flex items-center gap-1.5 text-xs"
                    style={{ color: 'hsl(var(--destructive))' }}
                  >
                    <AlertCircle className="w-3.5 h-3.5" />
                    连接失败
                  </span>
                )}
                {config.lastChecked && (
                  <span className="text-xs text-muted-foreground">
                    上次检查: {config.lastChecked.toLocaleTimeString('zh-CN')}
                  </span>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleCheck}
                  disabled={isChecking}
                >
                  <RefreshCw className={`w-4 h-4 mr-1.5 ${isChecking ? 'animate-spin' : ''}`} />
                  检查
                </Button>
                <Button
                  size="sm"
                  variant="default"
                  onClick={() => setIsEditing(true)}
                >
                  编辑
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Info Card */}
      <div 
        className="mt-5 p-4 rounded-2xl border"
        style={{
          backgroundColor: 'hsl(var(--md-sys-color-tertiary-container))',
          borderColor: 'hsl(var(--md-sys-color-tertiary-container))'
        }}
      >
        <h4 
          className="text-sm font-medium mb-2"
          style={{ color: 'hsl(var(--md-sys-color-on-tertiary-container))' }}
        >
          关于 Worker URL
        </h4>
        <p 
          className="text-xs leading-relaxed"
          style={{ color: 'hsl(var(--md-sys-color-on-tertiary-container))', opacity: 0.8 }}
        >
          Cloudflare Worker URL 用于代理 GitHub raw 内容请求。当模块检查更新时，
          原始 GitHub URL 会被替换为 Worker URL，从而加速访问。
        </p>
      </div>
    </div>
  );
}
