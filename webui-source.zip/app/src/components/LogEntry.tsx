import { Info, AlertTriangle, AlertCircle, CheckCircle2 } from 'lucide-react';
import type { LogEntry as LogEntryType } from '@/types';

interface LogEntryProps {
  entry: LogEntryType;
}

const levelConfig = {
  info: {
    icon: Info,
    bg: 'var(--md-sys-color-primary-container)',
    fg: 'var(--md-sys-color-on-primary-container)',
    label: '信息',
  },
  warning: {
    icon: AlertTriangle,
    bg: 'var(--md-sys-color-tertiary-container)',
    fg: 'var(--md-sys-color-on-tertiary-container)',
    label: '警告',
  },
  error: {
    icon: AlertCircle,
    bg: 'var(--md-sys-color-error-container)',
    fg: 'var(--md-sys-color-on-error-container)',
    label: '错误',
  },
  success: {
    icon: CheckCircle2,
    bg: 'var(--md-sys-color-primary-container)',
    fg: 'var(--md-sys-color-on-primary-container)',
    label: '成功',
  },
};

export function LogEntryItem({ entry }: LogEntryProps) {
  const config = levelConfig[entry.level];
  const Icon = config.icon;
  
  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('zh-CN', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(date);
  };

  return (
    <div className="flex items-start gap-3 py-3 px-4 hover:bg-surface-variant/50 transition-colors">
      {/* Level Icon */}
      <div 
        className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{
          backgroundColor: `hsl(${config.bg})`,
          color: `hsl(${config.fg})`
        }}
      >
        <Icon className="w-4 h-4" />
      </div>
      
      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-mono text-muted-foreground">
            {formatTime(entry.timestamp)}
          </span>
          
          <span 
            className="text-xs px-1.5 py-0.5 rounded-lg font-medium"
            style={{
              backgroundColor: `hsl(${config.bg})`,
              color: `hsl(${config.fg})`
            }}
          >
            {config.label}
          </span>
          
          {entry.moduleId && (
            <span 
              className="text-xs px-1.5 py-0.5 rounded-lg font-mono"
              style={{
                backgroundColor: 'hsl(var(--md-sys-color-surface-container))',
                color: 'hsl(var(--md-sys-color-on-surface-variant))'
              }}
            >
              {entry.moduleId}
            </span>
          )}
        </div>
        
        <p className="text-sm text-foreground mt-1.5 break-all">
          {entry.message}
        </p>
      </div>
    </div>
  );
}
