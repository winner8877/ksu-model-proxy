import { 
  Package, 
  ExternalLink, 
  RotateCcw, 
  CheckCircle2, 
  XCircle,
  Github,
  Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { ProxyModule } from '@/types';

interface ModuleCardProps {
  module: ProxyModule;
  onToggleProxy: (id: string) => void;
  onRestoreBackup?: (id: string) => void;
}

export function ModuleCard({ module, onToggleProxy, onRestoreBackup }: ModuleCardProps) {
  return (
    <div className="md3-card p-4 hover:shadow-md transition-all duration-200">
      <div className="flex items-start gap-4">
        {/* Icon */}
        <div 
          className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
          style={{
            backgroundColor: module.isProxied 
              ? 'hsl(var(--md-sys-color-primary-container))' 
              : 'hsl(var(--md-sys-color-surface-variant))',
            color: module.isProxied 
              ? 'hsl(var(--md-sys-color-on-primary-container))' 
              : 'hsl(var(--md-sys-color-on-surface-variant))'
          }}
        >
          {module.isProxied ? (
            <Shield className="w-6 h-6" />
          ) : (
            <Package className="w-6 h-6" />
          )}
        </div>
        
        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-semibold text-foreground truncate">{module.name}</h3>
              <p className="text-xs text-muted-foreground">{module.id}</p>
            </div>
            
            {/* Status Badge */}
            <span 
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium"
              style={{
                backgroundColor: module.isProxied 
                  ? 'hsl(var(--md-sys-color-primary-container))' 
                  : 'hsl(var(--md-sys-color-surface-variant))',
                color: module.isProxied 
                  ? 'hsl(var(--md-sys-color-on-primary-container))' 
                  : 'hsl(var(--md-sys-color-on-surface-variant))'
              }}
            >
              {module.isProxied ? (
                <>
                  <CheckCircle2 className="w-3 h-3" />
                  已代理
                </>
              ) : (
                <>
                  <XCircle className="w-3 h-3" />
                  未代理
                </>
              )}
            </span>
          </div>
          
          {module.description && (
            <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
              {module.description}
            </p>
          )}
          
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Package className="w-3.5 h-3.5" />
              v{module.version}
            </span>
            <span className="flex items-center gap-1">
              <Github className="w-3.5 h-3.5" />
              {module.author}
            </span>
          </div>
          
          {/* URL Display */}
          <div 
            className="mt-3 p-2.5 rounded-xl text-xs"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <p className="text-muted-foreground mb-1">原始 URL:</p>
            <p className="font-mono text-foreground truncate">{module.originalUrl}</p>
            {module.isProxied && module.proxiedUrl && (
              <>
                <p className="text-muted-foreground mt-2 mb-1">代理 URL:</p>
                <p 
                  className="font-mono truncate"
                  style={{ color: 'hsl(var(--md-sys-color-primary))' }}
                >
                  {module.proxiedUrl}
                </p>
              </>
            )}
          </div>
          
          {/* Actions */}
          <div className="flex items-center gap-2 mt-4">
            <Button
              size="sm"
              variant={module.isProxied ? 'destructive' : 'default'}
              onClick={() => onToggleProxy(module.id)}
              className="flex-1"
            >
              {module.isProxied ? (
                <>
                  <XCircle className="w-4 h-4 mr-1.5" />
                  禁用代理
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4 mr-1.5" />
                  启用代理
                </>
              )}
            </Button>
            
            {module.isProxied && module.hasBackup && onRestoreBackup && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onRestoreBackup(module.id)}
              >
                <RotateCcw className="w-4 h-4 mr-1.5" />
                恢复
              </Button>
            )}
            
            <Button
              size="sm"
              variant="ghost"
              onClick={() => window.open(module.originalUrl, '_blank')}
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
