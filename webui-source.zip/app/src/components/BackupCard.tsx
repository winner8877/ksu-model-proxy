import { Archive, Calendar, FolderOpen, RotateCcw, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { ModuleBackup } from '@/types';

interface BackupCardProps {
  backup: ModuleBackup;
  onRestore: (id: string) => void;
  onDelete: (id: string) => void;
}

export function BackupCard({ backup, onRestore, onDelete }: BackupCardProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  return (
    <div className="md3-card p-4">
      <div className="flex items-start gap-4">
        {/* Icon */}
        <div 
          className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
          style={{
            backgroundColor: 'hsl(var(--md-sys-color-secondary-container))',
            color: 'hsl(var(--md-sys-color-on-secondary-container))'
          }}
        >
          <Archive className="w-6 h-6" />
        </div>
        
        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground">{backup.moduleName}</h3>
          <p className="text-xs text-muted-foreground mt-0.5">{backup.moduleId}</p>
          
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              {formatDate(backup.createdAt)}
            </span>
          </div>
          
          {/* Path */}
          <div 
            className="mt-3 p-2.5 rounded-xl text-xs flex items-center gap-2"
            style={{ backgroundColor: 'hsl(var(--md-sys-color-surface-container))' }}
          >
            <FolderOpen className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            <span className="font-mono text-foreground truncate">{backup.backupPath}</span>
          </div>
          
          {/* Actions */}
          <div className="flex items-center gap-2 mt-4">
            <Button
              size="sm"
              variant="default"
              onClick={() => onRestore(backup.moduleId)}
              className="flex-1"
            >
              <RotateCcw className="w-4 h-4 mr-1.5" />
              恢复备份
            </Button>
            
            <Button
              size="sm"
              variant="destructive"
              onClick={() => onDelete(backup.moduleId)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
