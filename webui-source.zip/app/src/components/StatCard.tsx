import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: number | string;
  subtitle?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  icon: React.ElementType;
  color: 'primary' | 'success' | 'warning' | 'info' | 'destructive';
}

const colorMap = {
  primary: {
    bg: 'var(--md-sys-color-primary-container)',
    fg: 'var(--md-sys-color-on-primary-container)',
  },
  success: {
    bg: 'var(--md-sys-color-primary-container)',
    fg: 'var(--md-sys-color-on-primary-container)',
  },
  warning: {
    bg: 'var(--md-sys-color-tertiary-container)',
    fg: 'var(--md-sys-color-on-tertiary-container)',
  },
  info: {
    bg: 'var(--md-sys-color-secondary-container)',
    fg: 'var(--md-sys-color-on-secondary-container)',
  },
  destructive: {
    bg: 'var(--md-sys-color-error-container)',
    fg: 'var(--md-sys-color-on-error-container)',
  },
};

export function StatCard({ 
  title, 
  value, 
  subtitle, 
  trend, 
  trendValue, 
  icon: Icon,
  color 
}: StatCardProps) {
  const colors = colorMap[color];
  
  return (
    <div className="md3-card p-5">
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <h3 className="text-2xl font-bold text-foreground truncate">{value}</h3>
          
          {subtitle && (
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          )}
          
          {trend && (
            <div className="flex items-center gap-1 mt-2">
              {trend === 'up' && (
                <TrendingUp className="w-3.5 h-3.5" style={{ color: 'hsl(var(--success))' }} />
              )}
              {trend === 'down' && (
                <TrendingDown className="w-3.5 h-3.5" style={{ color: 'hsl(var(--destructive))' }} />
              )}
              {trend === 'neutral' && (
                <Minus className="w-3.5 h-3.5 text-muted-foreground" />
              )}
              <span 
                className="text-xs font-medium"
                style={{ 
                  color: trend === 'up' ? 'hsl(var(--success))' : 
                         trend === 'down' ? 'hsl(var(--destructive))' : 
                         'hsl(var(--muted-foreground))' 
                }}
              >
                {trendValue}
              </span>
            </div>
          )}
        </div>
        
        <div 
          className="w-12 h-12 rounded-2xl flex items-center justify-center"
          style={{ 
            backgroundColor: `hsl(${colors.bg})`,
            color: `hsl(${colors.fg})`
          }}
        >
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
