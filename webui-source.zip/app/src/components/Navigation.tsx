import { 
  LayoutDashboard, 
  Package, 
  Archive, 
  FileText, 
  Settings,
  Sun,
  Moon
} from 'lucide-react';
import type { ViewType } from '@/types';

interface NavigationProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

const navItems: { id: ViewType; label: string; icon: React.ElementType }[] = [
  { id: 'dashboard', label: '概览', icon: LayoutDashboard },
  { id: 'modules', label: '模块', icon: Package },
  { id: 'backups', label: '备份', icon: Archive },
  { id: 'logs', label: '日志', icon: FileText },
  { id: 'settings', label: '设置', icon: Settings },
];

export function Navigation({ 
  currentView, 
  onViewChange, 
  isDarkMode,
}: NavigationProps) {
  return (
    <aside className="fixed left-0 top-0 h-full w-20 lg:w-64 bg-surface-container border-r border-border flex flex-col z-50 transition-colors duration-300">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3 justify-center lg:justify-start">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ 
              backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
              color: 'hsl(var(--md-sys-color-on-primary-container))'
            }}
          >
            <Package className="w-5 h-5" />
          </div>
          <div className="hidden lg:block">
            <h1 className="font-semibold text-sm leading-tight">GitHub CF</h1>
            <p className="text-xs text-muted-foreground">Proxy Manager</p>
          </div>
        </div>
      </div>

      {/* Navigation Items */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`
                w-full flex items-center gap-3 px-3 py-3 rounded-2xl transition-all duration-200
                ${isActive 
                  ? 'font-medium' 
                  : 'text-foreground hover:bg-surface-variant'
                }
              `}
              style={isActive ? {
                backgroundColor: 'hsl(var(--md-sys-color-primary-container))',
                color: 'hsl(var(--md-sys-color-on-primary-container))'
              } : {}}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              <span className="hidden lg:block text-sm font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer - Theme Indicator */}
      <div className="p-3 border-t border-border">
        <div 
          className="w-full flex items-center gap-3 px-3 py-3 rounded-2xl"
          style={{
            backgroundColor: 'hsl(var(--md-sys-color-surface-container-high))'
          }}
        >
          {isDarkMode ? (
            <Moon className="w-5 h-5 flex-shrink-0" style={{ color: 'hsl(var(--md-sys-color-primary))' }} />
          ) : (
            <Sun className="w-5 h-5 flex-shrink-0" style={{ color: 'hsl(var(--md-sys-color-primary))' }} />
          )}
          <span className="hidden lg:block text-sm font-medium">
            {isDarkMode ? '深色模式' : '浅色模式'}
          </span>
          <span className="hidden lg:block text-xs text-muted-foreground ml-auto">
            自动
          </span>
        </div>
      </div>
    </aside>
  );
}
