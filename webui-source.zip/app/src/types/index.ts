// Module Types
export interface ProxyModule {
  id: string;
  name: string;
  version: string;
  author: string;
  description?: string;
  originalUrl: string;
  proxiedUrl: string;
  isProxied: boolean;
  hasBackup: boolean;
  lastModified: Date;
}

export interface ModuleBackup {
  moduleId: string;
  moduleName: string;
  backupPath: string;
  createdAt: Date;
}

export interface LogEntry {
  timestamp: Date;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  moduleId?: string;
}

export interface WorkerConfig {
  url: string;
  isValid: boolean;
  lastChecked: Date | null;
}

export interface ModuleStats {
  totalModules: number;
  proxiedModules: number;
  pendingModules: number;
  backupCount: number;
  lastScan: Date | null;
}

export type ViewType = 'dashboard' | 'modules' | 'backups' | 'logs' | 'settings';

export interface AppState {
  currentView: ViewType;
  isDarkMode: boolean;
  config: WorkerConfig;
  stats: ModuleStats;
  modules: ProxyModule[];
  backups: ModuleBackup[];
  logs: LogEntry[];
  isLoading: boolean;
}
