import { useState, useEffect, useCallback, useRef } from 'react';
import {
  execCommand,
  readFile,
  writeFile,
  fileExists,
  dirExists,
  mkdir,
  readModuleProp,
  writeModuleProp,
  isGitHubUrl,
  isProxiedUrl,
  buildWorkerUrl,
  readLogs,
  appendLog,
  runProxyScript,
  showToast,
  isKSUEnvironment,
  BACKUP_DIR,
  MODULES_DIR,
  CONFIG_FILE,
  LOG_FILE,
} from '@/utils/ksu';
import type { ProxyModule, ModuleBackup, LogEntry, WorkerConfig, ModuleStats } from '@/types';

// Parse log line to LogEntry
const parseLogLine = (line: string): LogEntry | null => {
  const match = line.match(/^\[(\d{2}-\d{2}\/\d{2}:\d{2})\]\s*(.*)$/);
  if (!match) return null;
  
  const [, timeStr, message] = match;
  const timestamp = new Date();
  const [month, dayHour] = timeStr.split('-');
  const [day, hour, minute] = (dayHour || '').split(/[\/:\s]/);
  
  if (month && day) {
    timestamp.setMonth(parseInt(month) - 1);
    timestamp.setDate(parseInt(day));
  }
  if (hour && minute) {
    timestamp.setHours(parseInt(hour), parseInt(minute));
  }
  
  // Determine log level
  let level: LogEntry['level'] = 'info';
  if (message.includes('错误') || message.includes('失败') || message.includes('Error')) {
    level = 'error';
  } else if (message.includes('警告') || message.includes('Warning') || message.includes('跳过')) {
    level = 'warning';
  } else if (message.includes('成功') || message.includes('已指向') || message.includes('已代理')) {
    level = 'success';
  }
  
  // Extract module ID if present
  const moduleMatch = message.match(/^\[([^\]]+)\]/);
  const moduleId = moduleMatch ? moduleMatch[1] : undefined;
  
  return {
    timestamp,
    level,
    message,
    moduleId,
  };
};

// Read worker URL from config
const readWorkerConfig = async (): Promise<string> => {
  try {
    const content = await readFile(CONFIG_FILE);
    const match = content.match(/CF_WORKER=["']?([^"'\n]+)["']?/);
    return match ? match[1] : 'https://qazqqaazz.dpdns.org';
  } catch {
    return 'https://qazqqaazz.dpdns.org';
  }
};

// Save worker URL to config
const saveWorkerConfig = async (url: string): Promise<void> => {
  const config = `CF_WORKER="${url}"\n`;
  await writeFile(CONFIG_FILE, config);
};

export function useKSU() {
  const [isReady, setIsReady] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [modules, setModules] = useState<ProxyModule[]>([]);
  const [backups, setBackups] = useState<ModuleBackup[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [config, setConfig] = useState<WorkerConfig>({
    url: 'https://qazqqaazz.dpdns.org',
    isValid: true,
    lastChecked: null,
  });
  const [stats, setStats] = useState<ModuleStats>({
    totalModules: 0,
    proxiedModules: 0,
    pendingModules: 0,
    backupCount: 0,
    lastScan: null,
  });
  
  const refreshIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Initialize - check KSU environment and load data
  useEffect(() => {
    const init = async () => {
      const inKSU = isKSUEnvironment();
      console.log('KSU Environment:', inKSU);
      
      // Ensure backup directory exists
      if (!(await dirExists(BACKUP_DIR))) {
        await mkdir(BACKUP_DIR);
      }
      
      // Load worker URL
      const workerUrl = await readWorkerConfig();
      setConfig(prev => ({ ...prev, url: workerUrl }));
      
      await refreshData();
      setIsReady(true);
      setIsLoading(false);
    };
    
    init();
    
    // Set up auto-refresh for logs
    refreshIntervalRef.current = setInterval(() => {
      refreshLogs();
    }, 3000);
    
    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, []);

  // Refresh all data
  const refreshData = useCallback(async () => {
    await Promise.all([
      refreshModules(),
      refreshLogs(),
    ]);
  }, []);

  // Refresh modules list
  const refreshModules = useCallback(async () => {
    const { errno, stdout } = await execCommand(`ls -1 "${MODULES_DIR}" 2>/dev/null || echo ""`);
    if (errno !== 0) return;
    
    const moduleIds = stdout.split('\n').filter(id => id && id !== 'github-cf-proxy');
    const loadedModules: ProxyModule[] = [];
    const loadedBackups: ModuleBackup[] = [];
    
    let proxiedCount = 0;
    let backupCount = 0;
    
    for (const moduleId of moduleIds) {
      const modulePath = `${MODULES_DIR}/${moduleId}`;
      const prop = await readModuleProp(modulePath);
      
      if (!prop.id) continue;
      
      const isProxied = prop.updateJson ? 
        isProxiedUrl(prop.updateJson, config.url) : false;
      const hasBackup = await fileExists(`${BACKUP_DIR}/${moduleId}.bak`);
      
      if (isProxied) proxiedCount++;
      if (hasBackup) backupCount++;
      
      const module: ProxyModule = {
        id: prop.id,
        name: prop.name || prop.id,
        version: prop.version || 'unknown',
        author: prop.author || 'Unknown',
        description: prop.description,
        originalUrl: hasBackup ? await readBackupUrl(moduleId) : (prop.updateJson || ''),
        proxiedUrl: prop.updateJson || '',
        isProxied,
        hasBackup,
        lastModified: new Date(),
      };
      
      loadedModules.push(module);
      
      if (hasBackup) {
        const { stdout: statOut } = await execCommand(`stat -c %Y "${BACKUP_DIR}/${moduleId}.bak" 2>/dev/null || echo "0"`);
        loadedBackups.push({
          moduleId: prop.id,
          moduleName: prop.name || prop.id,
          backupPath: `${BACKUP_DIR}/${moduleId}.bak`,
          createdAt: new Date(parseInt(statOut.trim()) * 1000),
        });
      }
    }
    
    // Calculate pending modules (GitHub URLs that are not proxied)
    const pendingCount = loadedModules.filter(m => 
      !m.isProxied && isGitHubUrl(m.originalUrl)
    ).length;
    
    setModules(loadedModules);
    setBackups(loadedBackups);
    setStats({
      totalModules: loadedModules.length,
      proxiedModules: proxiedCount,
      pendingModules: pendingCount,
      backupCount,
      lastScan: new Date(),
    });
  }, [config.url]);

  // Read original URL from backup
  const readBackupUrl = async (moduleId: string): Promise<string> => {
    try {
      const content = await readFile(`${BACKUP_DIR}/${moduleId}.bak`);
      const match = content.match(/^updateJson=(.+)$/m);
      return match ? match[1] : '';
    } catch {
      return '';
    }
  };

  // Refresh logs
  const refreshLogs = useCallback(async () => {
    const logLines = await readLogs();
    const parsedLogs = logLines
      .map(parseLogLine)
      .filter((log): log is LogEntry => log !== null)
      .reverse();
    setLogs(parsedLogs);
  }, []);

  // Update worker URL
  const updateWorkerUrl = useCallback(async (url: string) => {
    await saveWorkerConfig(url);
    setConfig(prev => ({ ...prev, url, lastChecked: new Date() }));
    await appendLog(`Worker URL 已更新: ${url}`);
    showToast('Worker URL 已更新');
    await refreshData();
  }, [refreshData]);

  // Toggle proxy for a module
  const toggleProxy = useCallback(async (moduleId: string) => {
    const module = modules.find(m => m.id === moduleId);
    if (!module) return;
    
    const modulePath = `${MODULES_DIR}/${moduleId}`;
    const prop = await readModuleProp(modulePath);
    
    if (module.isProxied) {
      // Disable proxy - restore original URL
      if (module.hasBackup) {
        const backupContent = await readFile(`${BACKUP_DIR}/${moduleId}.bak`);
        const originalUrl = backupContent.match(/^updateJson=(.+)$/m)?.[1] || '';
        prop.updateJson = originalUrl;
        await writeModuleProp(modulePath, prop);
        await appendLog(`[${moduleId}] 代理已禁用`);
        showToast(`${module.name} 代理已禁用`);
      }
    } else {
      // Enable proxy - backup and replace URL
      if (!module.hasBackup && prop.updateJson) {
        // Create backup
        await writeFile(`${BACKUP_DIR}/${moduleId}.bak`, `updateJson=${prop.updateJson}\n`);
      }
      
      if (prop.updateJson && isGitHubUrl(prop.updateJson)) {
        const newUrl = buildWorkerUrl(prop.updateJson, config.url);
        prop.updateJson = newUrl;
        await writeModuleProp(modulePath, prop);
        await appendLog(`[${moduleId}] 已指向 Worker`);
        showToast(`${module.name} 已启用代理`);
      }
    }
    
    await refreshData();
  }, [modules, config.url, refreshData]);

  // Restore backup
  const restoreBackup = useCallback(async (moduleId: string) => {
    const backupPath = `${BACKUP_DIR}/${moduleId}.bak`;
    if (!(await fileExists(backupPath))) {
      showToast('备份不存在');
      return;
    }
    
    const backupContent = await readFile(backupPath);
    const originalUrl = backupContent.match(/^updateJson=(.+)$/m)?.[1];
    
    if (originalUrl) {
      const modulePath = `${MODULES_DIR}/${moduleId}`;
      const prop = await readModuleProp(modulePath);
      prop.updateJson = originalUrl;
      await writeModuleProp(modulePath, prop);
      // 删除备份文件
      await execCommand(`rm -f "${backupPath}"`);
      await appendLog(`[${moduleId}] 备份已恢复并删除`);
      showToast('备份已恢复');
      await refreshData();
    }
  }, [refreshData]);

  // Delete backup
  const deleteBackup = useCallback(async (moduleId: string) => {
    const backupPath = `${BACKUP_DIR}/${moduleId}.bak`;
    await execCommand(`rm -f "${backupPath}"`);
    await appendLog(`[${moduleId}] 备份已删除`);
    showToast('备份已删除');
    await refreshData();
  }, [refreshData]);

  // Run proxy script
  const runScan = useCallback(async () => {
    setIsLoading(true);
    await appendLog('=== 手动扫描开始 ===');
    try {
      await runProxyScript();
      showToast('扫描完成');
    } catch (error) {
      showToast('扫描失败: ' + (error as Error).message);
    }
    await refreshData();
    setIsLoading(false);
  }, [refreshData]);

  // Clear logs
  const clearLogs = useCallback(async () => {
    await writeFile(LOG_FILE, '');
    setLogs([]);
    showToast('日志已清空');
  }, []);

  // Check worker connection using ping
  const checkWorker = useCallback(async (): Promise<boolean> => {
    try {
      // Extract hostname from URL
      const hostname = config.url.replace(/^https?:\/\//, '').split('/')[0];
      
      // Use ping command to check connectivity
      const { errno } = await execCommand(`ping -c 1 -W 3 "${hostname}" > /dev/null 2>&1`);
      
      const isValid = errno === 0;
      setConfig(prev => ({ ...prev, isValid, lastChecked: new Date() }));
      
      if (isValid) {
        showToast('Worker 连接正常');
      } else {
        showToast('Worker 连接失败');
      }
      
      return isValid;
    } catch {
      setConfig(prev => ({ ...prev, isValid: false, lastChecked: new Date() }));
      showToast('Worker 连接失败');
      return false;
    }
  }, [config.url]);

  return {
    // State
    isReady,
    isLoading,
    modules,
    backups,
    logs,
    config,
    stats,
    isKSU: isKSUEnvironment(),
    
    // Actions
    updateWorkerUrl,
    toggleProxy,
    restoreBackup,
    deleteBackup,
    runScan,
    clearLogs,
    checkWorker,
  };
}
