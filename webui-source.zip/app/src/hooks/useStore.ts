import { useState, useCallback, useEffect } from 'react';
import type { 
  ProxyModule, 
  ModuleBackup, 
  LogEntry, 
  WorkerConfig, 
  ModuleStats,
  ViewType 
} from '@/types';

// Mock data for demonstration
const generateMockModules = (): ProxyModule[] => [
  {
    id: 'zygisk-detach',
    name: 'Zygisk Detach',
    version: '1.0.0',
    author: 'j-hc',
    description: 'Zygisk module to detach apps from Play Store',
    originalUrl: 'https://raw.githubusercontent.com/j-hc/zygisk-detach/main/update.json',
    proxiedUrl: 'https://qazqqaazz.dpdns.org/?url=https%3A%2F%2Fraw.githubusercontent.com%2Fj-hc%2Fzygisk-detach%2Fmain%2Fupdate.json',
    isProxied: true,
    hasBackup: true,
    lastModified: new Date('2024-01-15'),
  },
  {
    id: 'magisk-frida',
    name: 'Magisk Frida',
    version: '16.1.11',
    author: 'ViRb3',
    description: 'Run Frida server on boot with Magisk',
    originalUrl: 'https://raw.githubusercontent.com/ViRb3/magisk-frida/master/update.json',
    proxiedUrl: 'https://qazqqaazz.dpdns.org/?url=https%3A%2F%2Fraw.githubusercontent.com%2FViRb3%2Fmagisk-frida%2Fmaster%2Fupdate.json',
    isProxied: true,
    hasBackup: true,
    lastModified: new Date('2024-01-14'),
  },
  {
    id: 'magisk-module-magic',
    name: 'Magisk Module Magic',
    version: '2.3.0',
    author: 'Magisk-Modules-Repo',
    description: 'A collection of useful utilities',
    originalUrl: 'https://raw.githubusercontent.com/Magisk-Modules-Repo/magic/main/update.json',
    proxiedUrl: '',
    isProxied: false,
    hasBackup: false,
    lastModified: new Date('2024-01-10'),
  },
  {
    id: 'adguard-dns',
    name: 'AdGuard DNS',
    version: '1.0.5',
    author: 'AdGuard',
    description: 'System-wide ad blocking via DNS',
    originalUrl: 'https://raw.githubusercontent.com/AdGuard/AdGuardDNS/master/update.json',
    proxiedUrl: 'https://qazqqaazz.dpdns.org/?url=https%3A%2F%2Fraw.githubusercontent.com%2FAdGuard%2FAdGuardDNS%2Fmaster%2Fupdate.json',
    isProxied: true,
    hasBackup: true,
    lastModified: new Date('2024-01-13'),
  },
  {
    id: 'youtube-revanced',
    name: 'YouTube ReVanced',
    version: '18.45.43',
    author: 'ReVanced',
    description: 'YouTube with ad blocking and custom features',
    originalUrl: 'https://raw.githubusercontent.com/revanced-apks/youtube-extended/main/update.json',
    proxiedUrl: '',
    isProxied: false,
    hasBackup: false,
    lastModified: new Date('2024-01-12'),
  },
];

const generateMockBackups = (modules: ProxyModule[]): ModuleBackup[] => 
  modules
    .filter(m => m.hasBackup)
    .map(m => ({
      moduleId: m.id,
      moduleName: m.name,
      backupPath: `/data/adb/modules/github-cf-proxy/backup/${m.id}.bak`,
      createdAt: m.lastModified,
    }));

const generateMockLogs = (): LogEntry[] => [
  { timestamp: new Date(), level: 'info', message: '=== CF Worker 代理启动 ===' },
  { timestamp: new Date(Date.now() - 1000), level: 'info', message: 'Worker: https://qazqqaazz.dpdns.org' },
  { timestamp: new Date(Date.now() - 2000), level: 'success', message: '[zygisk-detach] 已指向 Worker', moduleId: 'zygisk-detach' },
  { timestamp: new Date(Date.now() - 3000), level: 'success', message: '[magisk-frida] 已指向 Worker', moduleId: 'magisk-frida' },
  { timestamp: new Date(Date.now() - 4000), level: 'info', message: '[magisk-module-magic] 原始: https://raw.githubusercontent.com...', moduleId: 'magisk-module-magic' },
  { timestamp: new Date(Date.now() - 5000), level: 'warning', message: '[youtube-revanced] 不含 GitHub 链接，跳过', moduleId: 'youtube-revanced' },
  { timestamp: new Date(Date.now() - 6000), level: 'success', message: '[adguard-dns] 已指向 Worker', moduleId: 'adguard-dns' },
  { timestamp: new Date(Date.now() - 7000), level: 'info', message: '=== 扫描完成 ===' },
];

export function useStore() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [config, setConfig] = useState<WorkerConfig>({
    url: 'https://qazqqaazz.dpdns.org',
    isValid: true,
    lastChecked: new Date(),
  });
  const [modules, setModules] = useState<ProxyModule[]>([]);
  const [backups, setBackups] = useState<ModuleBackup[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<ModuleStats>({
    totalModules: 0,
    proxiedModules: 0,
    pendingModules: 0,
    backupCount: 0,
    lastScan: null,
  });

  // Initialize data
  useEffect(() => {
    const initData = () => {
      const mockModules = generateMockModules();
      const mockBackups = generateMockBackups(mockModules);
      const mockLogs = generateMockLogs();
      
      setModules(mockModules);
      setBackups(mockBackups);
      setLogs(mockLogs);
      setStats({
        totalModules: mockModules.length,
        proxiedModules: mockModules.filter(m => m.isProxied).length,
        pendingModules: mockModules.filter(m => !m.isProxied && m.originalUrl.includes('github')).length,
        backupCount: mockBackups.length,
        lastScan: new Date(),
      });
      setIsLoading(false);
    };

    setTimeout(initData, 500);
  }, []);

  // Actions
  const updateWorkerUrl = useCallback((url: string) => {
    setConfig(prev => ({
      ...prev,
      url,
      lastChecked: new Date(),
    }));
    
    // Add log entry
    const newLog: LogEntry = {
      timestamp: new Date(),
      level: 'info',
      message: `Worker URL 已更新: ${url}`,
    };
    setLogs(prev => [newLog, ...prev]);
  }, []);

  const toggleProxy = useCallback((moduleId: string) => {
    setModules(prev => prev.map(module => {
      if (module.id !== moduleId) return module;
      
      const newIsProxied = !module.isProxied;
      const newLog: LogEntry = {
        timestamp: new Date(),
        level: newIsProxied ? 'success' : 'info',
        message: `[${module.id}] ${newIsProxied ? '已启用代理' : '已禁用代理'}`,
        moduleId: module.id,
      };
      setLogs(logs => [newLog, ...logs]);
      
      return {
        ...module,
        isProxied: newIsProxied,
        proxiedUrl: newIsProxied 
          ? `${config.url}/?url=${encodeURIComponent(module.originalUrl)}`
          : '',
      };
    }));
  }, [config.url]);

  const restoreBackup = useCallback((moduleId: string) => {
    setModules(prev => prev.map(module => {
      if (module.id !== moduleId) return module;
      
      const newLog: LogEntry = {
        timestamp: new Date(),
        level: 'success',
        message: `[${module.id}] 备份已恢复`,
        moduleId: module.id,
      };
      setLogs(logs => [newLog, ...logs]);
      
      return {
        ...module,
        isProxied: false,
        proxiedUrl: '',
      };
    }));
  }, []);

  const deleteBackup = useCallback((moduleId: string) => {
    setBackups(prev => prev.filter(b => b.moduleId !== moduleId));
    setModules(prev => prev.map(module => 
      module.id === moduleId 
        ? { ...module, hasBackup: false }
        : module
    ));
    
    const newLog: LogEntry = {
      timestamp: new Date(),
      level: 'info',
      message: `[${moduleId}] 备份已删除`,
      moduleId,
    };
    setLogs(prev => [newLog, ...prev]);
  }, []);

  const runScan = useCallback(() => {
    setIsLoading(true);
    
    setTimeout(() => {
      const newLog: LogEntry = {
        timestamp: new Date(),
        level: 'info',
        message: '=== 手动扫描开始 ===',
      };
      setLogs(prev => [newLog, ...prev]);
      
      setStats(prev => ({
        ...prev,
        lastScan: new Date(),
      }));
      setIsLoading(false);
    }, 1500);
  }, []);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode(prev => !prev);
  }, []);

  return {
    // State
    currentView,
    isDarkMode,
    config,
    modules,
    backups,
    logs,
    isLoading,
    stats,
    
    // Actions
    setCurrentView,
    updateWorkerUrl,
    toggleProxy,
    restoreBackup,
    deleteBackup,
    runScan,
    clearLogs,
    toggleDarkMode,
  };
}
